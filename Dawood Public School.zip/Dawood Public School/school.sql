-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2018 at 10:29 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school`
--

-- --------------------------------------------------------

--
-- Table structure for table `img_slider`
--

CREATE TABLE `img_slider` (
  `img_id` int(11) NOT NULL,
  `img_name` varchar(50) NOT NULL,
  `img_title` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `img_slider`
--

INSERT INTO `img_slider` (`img_id`, `img_name`, `img_title`) VALUES
(1, 'slider-1.jpg', ''),
(2, 'slider-2.jpg', ''),
(3, 'slider-3.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `login_admin`
--

CREATE TABLE `login_admin` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_pass` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_admin`
--

INSERT INTO `login_admin` (`id`, `user_name`, `user_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `school_info`
--

CREATE TABLE `school_info` (
  `school_mail` varchar(60) NOT NULL,
  `school_no` int(60) NOT NULL,
  `school_addr` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_info`
--

INSERT INTO `school_info` (`school_mail`, `school_no`, `school_addr`) VALUES
('fawad@gmail.com', 341320831, 'Multan , Cantt');

-- --------------------------------------------------------

--
-- Table structure for table `school_nav`
--

CREATE TABLE `school_nav` (
  `nav_id` int(6) NOT NULL,
  `nav_title` varchar(35) NOT NULL,
  `nav_url` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_nav`
--

INSERT INTO `school_nav` (`nav_id`, `nav_title`, `nav_url`) VALUES
(1, 'Home', 'index.php'),
(2, 'News', 'news.php'),
(3, 'About Us', 'about.php'),
(4, 'Contact', 'contact.php');

-- --------------------------------------------------------

--
-- Table structure for table `school_success`
--

CREATE TABLE `school_success` (
  `data_students` int(10) NOT NULL,
  `data_teachers` int(10) NOT NULL,
  `data_passing` int(10) NOT NULL,
  `data_parents` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_success`
--

INSERT INTO `school_success` (`data_students`, `data_teachers`, `data_passing`, `data_parents`) VALUES
(2500, 200, 100, '100');

-- --------------------------------------------------------

--
-- Table structure for table `school_testimony`
--

CREATE TABLE `school_testimony` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_pic` varchar(50) NOT NULL,
  `student_stat` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school_testimony`
--

INSERT INTO `school_testimony` (`student_id`, `student_name`, `student_pic`, `student_stat`) VALUES
(1, 'Ahmad', 'person_1.jpg', 'Amazing experience in this school'),
(2, 'Ahsan', 'person_2.jpg', 'Was the worst school i have ever been to.'),
(3, 'Ali', 'person_3.jpg', 'Best school');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `img_slider`
--
ALTER TABLE `img_slider`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `login_admin`
--
ALTER TABLE `login_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school_info`
--
ALTER TABLE `school_info`
  ADD PRIMARY KEY (`school_mail`);

--
-- Indexes for table `school_nav`
--
ALTER TABLE `school_nav`
  ADD PRIMARY KEY (`nav_id`);

--
-- Indexes for table `school_testimony`
--
ALTER TABLE `school_testimony`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `img_slider`
--
ALTER TABLE `img_slider`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login_admin`
--
ALTER TABLE `login_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `school_nav`
--
ALTER TABLE `school_nav`
  MODIFY `nav_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `school_testimony`
--
ALTER TABLE `school_testimony`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
