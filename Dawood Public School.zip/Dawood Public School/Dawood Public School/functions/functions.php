<?php
//include 'includes/db.php';
function getSchoolInfo($value) {
include 'includes/db.php';
$sql = "SELECT school_mail, school_no, school_addr FROM school_info";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
      $mail=$row["school_mail"];
       $no=$row["school_no"];
        $addr=$row["school_addr"];
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
if($value==1){
    echo $mail;
}
    if($value==2){
    echo $no;
}
    if($value==3){
    echo $addr;
}
    
}

function getNavData() {
include 'includes/db.php';
$sql = "SELECT * FROM school_nav";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo '<li><a href="' . $row['nav_url'] . '">'.$row['nav_title'].'</a></li>';
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
    
}

function getSliderData() {
include 'includes/db.php';
$sql = "SELECT * FROM img_slider";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        
        echo           '<li style="background-image: url(img/'.$row['img_name'].')" class="overlay">
            <div class="container">
              <div class="row">
                <div class="col-md-8 col-md-offset-2">
                  <div class="probootstrap-slider-text text-center">
                    <h1 class="probootstrap-heading probootstrap-animate">'.$row['img_title'].'</h1>
                  </div>
                </div>
              </div>
            </div>
          </li>';
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
    
}

function getSchoolSuccess($value) {
//$sql = "SELECT * FROM school_success";
include 'includes/db.php';
$sql = "SELECT data_students, data_teachers,data_passing,data_parents FROM school_success";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
      $student_enrolled=$row["data_students"];
       $teachers=$row["data_teachers"];
        $student_passed=$row["data_passing"];
        $parents_satis=$row["data_parents"];
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
if($value==1){
    $res=$student_enrolled;
}
    if($value==2){
    $res= $teachers;
}
    if($value==3){
    $res= $student_passed;
}
        if($value==4){
    $res= $parents_satis;
}

echo $res;
    
    
}

function getTestimonyData() {
include 'includes/db.php';
$sql = "SELECT * FROM school_testimony";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        
        echo '<div class="item">
                <div class="probootstrap-testimony-wrap text-center">
                    <figure>
                      <img src="img/'.$row["student_pic"].'" alt="Free Bootstrap Template by ProBootstrap.com">
                    </figure>
                    <blockquote class="quote">&ldquo;'.$row["student_stat"].'.&rdquo; <cite class="author"> &mdash; <span>'.$row["student_name"].'</span></cite></blockquote>
                  </div>
                </div>';
    }
} else {
    echo "0 results";
}

mysqli_close($conn);
    
}



?>